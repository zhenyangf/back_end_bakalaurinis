package com.bakalaurinis.model;

public enum EventStatus {
    PENDING_REVIEW,
    PENDING_PAYOUT,
    SETTLED,
    REJECTED,
}
