package com.bakalaurinis.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class InsuranceMapper {


    public static InsuranceDto toInsuranceDto(Insurance insurance){
        return InsuranceDto.builder()
                .title(insurance.getTitle())
                .status(insurance.getStatus())
                .category(insurance.getCategory())
                .address(insurance.getAddress())
                .userId(insurance.getUser().getId())
                .build();
    }
    public static InsuranceDtoWithEvents insuranceDtoWithEvents(Insurance insurance){

     long currentid = insurance.getId();

        List <EventDto2> events = new ArrayList<>();
            for (var event : insurance.getEvents()) {
                    events.add(EventMapper.toeventDto2(event));

            }

        return InsuranceDtoWithEvents.builder()
                .title(insurance.getTitle())
                .category(insurance.getCategory())
                .address(insurance.getAddress())
                .events(events)
                .status(insurance.getStatus())
                .userId(insurance.getUser().getId())
                .id(insurance.getId())
                .build();
    }
    public static Insurance toInsurance(InsuranceDto insuranceDto, User user){
        return Insurance.builder()
                .title(insuranceDto.getTitle())
                .status(insuranceDto.getStatus())
                .category(insuranceDto.getCategory())
                .address(insuranceDto.getAddress())
                .user(user)
                .build();

    }

    public static InsuranceResponseDto toResponseDto(Insurance insurance){
        return  InsuranceResponseDto.builder()
                .id(insurance.getId())
                .title(insurance.getTitle())
                .status(insurance.getStatus())
                .category(insurance.getCategory())
                .address(insurance.getAddress())
                .userId(insurance.getUser().getId())
                .build();

    }

}
