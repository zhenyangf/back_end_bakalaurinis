package com.bakalaurinis.model;

public enum InsuranceStatus {
    PENDING,
    APPROVED,
    REJECTED,
}
