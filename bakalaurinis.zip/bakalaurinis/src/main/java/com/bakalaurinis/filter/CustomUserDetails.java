//package com.bakalaurinis.filter;
//
//public class CustomUserDetails implements TokenEnhancer{
//}
