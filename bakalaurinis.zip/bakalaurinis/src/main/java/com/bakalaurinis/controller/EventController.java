package com.bakalaurinis.controller;

import com.bakalaurinis.model.EventCreationDto;
import com.bakalaurinis.model.EventDto;
import com.bakalaurinis.model.EventResponseDto;
import com.bakalaurinis.model.InsuranceDto;
import com.bakalaurinis.repository.EventRepository;
import com.bakalaurinis.services.EventService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
@RequestMapping("api/insurance")
public class EventController {
    @Autowired
    EventRepository eventRepository;
    @Autowired
    EventService eventService;
    //idet image
    @PostMapping("/event/add")
    public EventResponseDto addnewevent(EventCreationDto eventDto, @RequestParam(name="file", required=false) MultipartFile file) throws IOException {
        return eventService.saveEvent(eventDto,file);
    }



    @GetMapping("/event/{id}")
    public Optional<EventDto>  getEvent(@PathVariable Long id){
        return eventService.getEventDto(id);
    }
    @GetMapping("/{id}/event")
    public List<EventResponseDto> getEventByInsuranceId(@PathVariable Long id){
        return eventService.getEvenyByInsuranceId(id);
    }



}
